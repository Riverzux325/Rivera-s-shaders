GtxShader — Minecraft Java 1.21.11 (lightweight starter pack)
============================================================

Designed to keep shader workload low on a GTX 1650 while streaming.
This pack uses very subtle color tuning and intentionally avoids expensive effects:
dynamic shadows, bloom, motion blur, depth of field, SSAO, and volumetric lighting.

Install:
1. Keep this ZIP compressed; do not extract it.
2. Put GtxShader_1.21.11.zip into .minecraft/shaderpacks
3. Start Minecraft 1.21.11 using a compatible Iris build.
4. Open Options > Video Settings > Shader Packs and select GtxShader.

Compatibility note:
Shader compatibility depends on the Iris version and the Minecraft release.
This is a lightweight starter pack, not a performance guarantee; it has not been
tested on the user's exact installation.

Suggested stream settings:
- Render distance: 8–12 chunks
- Simulation distance: 5–6 chunks
- Graphics: Fast
- Clouds: Off
- Particles: Decreased
- OBS: try NVENC; use 720p60 or 1080p30 if frames drop.
