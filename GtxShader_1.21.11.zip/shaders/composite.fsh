#version 120
uniform sampler2D colortex0;
varying vec2 texcoord;
void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    color = (color - 0.5) * 1.035 + 0.5;
    float gray = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(vec3(gray), color, 1.035);
    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
