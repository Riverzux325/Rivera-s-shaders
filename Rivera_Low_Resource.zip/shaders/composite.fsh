#version 120
uniform sampler2D colortex0;
varying vec2 texcoord;
void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    // Very subtle contrast curve, low cost.
    color = color / (vec3(0.98) + color);
    gl_FragColor = vec4(color, 1.0);
}
