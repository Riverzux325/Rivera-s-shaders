#version 120
uniform sampler2D texture;
varying vec2 texcoord;
varying vec4 glcolor;
void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    // Slightly richer natural colors without expensive post-processing.
    color.rgb = mix(color.rgb, color.rgb * vec3(1.03, 1.04, 1.05), 0.35);
    gl_FragColor = color;
}
