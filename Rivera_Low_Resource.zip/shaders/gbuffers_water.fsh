#version 120
uniform sampler2D texture;
uniform float frameTimeCounter;
varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 viewPos;
void main() {
    vec4 tex = texture2D(texture, texcoord) * glcolor;
    float waveA = sin(texcoord.x * 38.0 + frameTimeCounter * 1.3);
    float waveB = cos(texcoord.y * 31.0 - frameTimeCounter * 1.1);
    float ripple = (waveA * waveB) * 0.025;
    vec3 deepWater = vec3(0.035, 0.24, 0.31);
    vec3 shallowWater = vec3(0.12, 0.43, 0.48);
    float depthTint = clamp(tex.b * 0.65 + tex.g * 0.25, 0.0, 1.0);
    vec3 water = mix(deepWater, shallowWater, depthTint);
    water += vec3(0.22, 0.30, 0.31) * max(ripple, 0.0);
    vec3 result = mix(tex.rgb, water, 0.28);
    gl_FragColor = vec4(result, tex.a);
}
