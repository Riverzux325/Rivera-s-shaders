RIVERA'S LOW RESOURCE — Starter shader pack
Minecraft Java 1.21.11 | Iris Shaders | Low-resource preset

IMPORTANT
This is a lightweight starter shader pack/source project, not a fully production-tested
shader. It uses simple water tinting, subtle animated water color variation, and basic
shadow-map passes. Actual water reflections are limited; convincing screen-space
reflections and polished shadow filtering require further shader development and testing
on the target GPU/driver.

INSTALL
1. Install Iris for Minecraft Java 1.21.11 (the Iris installer includes Sodium).
2. Keep this ZIP compressed.
3. Press Win+R, enter %appdata%\.minecraft\shaderpacks and press Enter.
4. Copy Rivera_RTX_Lite.zip into that folder.
5. In Minecraft: Options > Video Settings > Shader Packs, select Rivera's Low Resource.
6. Start with render distance 8 chunks and shadow resolution 512. If performance is good,
   try 8–10 chunks and shadow resolution 1024.

If it crashes or shows a shader compile error, disable it from the Shader Packs menu or
press K (Iris default toggle in many configurations), then share latest.log / shader error.

The pack does not require a resource pack. Back up worlds before testing mods, as usual.
